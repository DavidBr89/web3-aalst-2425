import React from "react";

const ProductsPage = () => {
  return <div className="p-4">PRODUCTEN</div>;
};

export default ProductsPage;
